# POS GAME in Python
This is a shooting game series and incorporates the concept of pursuing scholarships for college students

## creator

Tan Tai and Team

Please Subscribe My Youtube channel

Name:  Tấn Tài

Youtube: https://www.youtube.com/channel/UCl3FtEWoxIBDFIB4vXm9jjg

Instagram: https://www.instagram.com/_d.ttai?igshid=OGQ5ZDc2ODk2ZA==## Running

* $ pip install pygame
* $ shooter main.py  --> run game

## Controls

* A: Move left  // Left Arrow
* D: Move right  //Right Arror
* W: Jump       //Up Arror
* SPACE: Shooting
* Q: Throw pencils // kinds of boom
* Esc: Exit game without press button
* Left/Right Mouseclick: Secret

## Dependencies	
* pygame	
* scipy	

## Contribution

If you have any Improvements/Ideas/Refactors feel free to contact me or make a Pull Request.
The code needs still alot of refactoring as it is right now, so I appreciate any kind of Contribution.
Techcombank: 4405 5668 6868 - DINH TAN TAI
